create function pg_sleep_until(timestamp with time zone) returns void
    strict
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function pg_sleep_until(timestamp with time zone) is 'sleep until the specified time';

alter function pg_sleep_until(timestamp with time zone) owner to postgres;

